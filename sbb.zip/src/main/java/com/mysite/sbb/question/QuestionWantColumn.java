package com.mysite.sbb.question;

public interface QuestionWantColumn {
	String getSubject();
	String getContent();
}
